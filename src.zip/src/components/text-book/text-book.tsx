import Header from "../header/header";

const TextBook: React.FC = () => {
  return (
    <>
      <Header />

      <main>
        <div className="container">
          <h1>TextBook</h1>
        </div>
      </main>
    </>
  );
}

export default TextBook;